import json
import boto3
from datetime import datetime
from decimal import Decimal

# Initialize clients
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
s3 = boto3.client('s3', region_name='us-east-1')

# Your DynamoDB Table and S3 Bucket
table_name = 'ChocolateHighValueSales'
bucket_name = 'chocolate-sales-processed-events'

# DynamoDB Table Reference
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    for record in event['Records']:
        try:
            # Step 1: Load outer SNS wrapper
            body = json.loads(record['body'])
            print("✅ Raw SQS body loaded:", body)

            # Step 2: Extract "Message" from SNS
            sns_message = body['Message']  # Still string JSON
            print("✅ Extracted SNS Message:", sns_message)

            # Step 3: Parse inner actual high-value sale JSON
            high_value_sale = json.loads(sns_message)
            print("✅ Parsed High Value Sale:", high_value_sale)

            # Step 4: Store in DynamoDB (Decimal needed for numeric types)
            dynamodb_item = {
                'timestamp': high_value_sale['timestamp'],
                'product': high_value_sale['product'],
                'amount': Decimal(str(high_value_sale['amount'])),
                'quantity': Decimal(str(high_value_sale['quantity'])),
                'customer_type': high_value_sale['customer_type'],
                'location': high_value_sale['location'],
                'high_value_flag': high_value_sale['high_value_flag']
            }
            table.put_item(Item=dynamodb_item)
            print("✅ Stored in DynamoDB.")

            # Step 5: Store JSON in S3 (optional for backup/logging)
            timestamp = datetime.fromisoformat(high_value_sale['timestamp'])
            s3_key = f"real-time-sales/{timestamp.year}/{timestamp.month:02d}/{timestamp.day:02d}/chocolate_sales_{timestamp.isoformat().replace(':', '-')}.json"
            s3.put_object(
                Bucket=bucket_name,
                Key=s3_key,
                Body=json.dumps(high_value_sale, indent=2),
                ContentType='application/json'
            )
            print(f"✅ Stored in S3 as {s3_key}.")

        except Exception as e:
            print(f"❌ Error processing record: {e}")
            print("Offending record:", record)

    return {
        'statusCode': 200,
        'body': json.dumps('✅ All high-value sales processed and stored.')
    }
